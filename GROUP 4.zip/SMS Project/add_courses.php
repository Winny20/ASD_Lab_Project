<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
	$query = "insert into courses values('$_POST[course_id]','$_POST[coursename]')";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Course added successfully.");
	window.location.href = "admin_dashboard.php";
</script>



