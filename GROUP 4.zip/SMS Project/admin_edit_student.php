<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
	$query = "update student set name='$_POST[name]',dob='$_POST[dob]',phone_no='$_POST[phone_no]',email='$_POST[email]' where clg_id = '$_POST[clg_id]'";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Details edited successfully.");
	window.location.href = "admin_dashboard.php";
</script>
