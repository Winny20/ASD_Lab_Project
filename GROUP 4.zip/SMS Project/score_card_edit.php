<?php
	$connection = mysqli_connect("localhost","root","");
    $db = mysqli_select_db($connection,"sms");
	$query = "update score_card set tot_internal ='$_POST[tot_internal]' where (clg_id ='$_POST[clg_id]' and semester ='$_POST[semester]' and course_id ='$_POST[course_id]')";
	//echo $query;
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Details edited successfully.");
	window.location.href = "admin_dashboard.php";
</script>
