<!DOCTYPE html>
<html>
<head>
	<title>Admin Dashboard</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		#header{
			height: 10%;
			width: 100%;
			top: 2%;
			background-color: black;
			position: fixed;
			color: white;
		}
		#left_side{
			height: 75%;
			width: 15%;
			top: 10%;
			position: fixed;
		}
		#right_side{
			height: 75%;
			width: 80%;
			background-color: whitesmoke;
			position: fixed;
			overflow-y:scroll;
			left: 17%;
			top: 21%;
			color: red;
			padding-bottom: 5%;
			border: solid 1px black;
		}
		#top_span{
			top: 15%;
			width: 80%;
			left: 17%;
			position: fixed;
		}
		#td{
			border: 1px solid black;
			padding-left: 2px;
			text-align: left;
			width: 200px;
		}
	</style>
	<?php
		session_start();
		$name = "";
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"sms");
	?>
</head>
<body>
	<div id="header"><br>
	<center>Student Management System &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;User ID: <?php echo $_SESSION['user_id'];?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name:<?php echo $_SESSION['name'];?>
	<a href="logout.php">Logout</a>
	</center>
	</div>
	<span id="top_span"><marquee>Note:- This portal is open till 31 March 2021...Please edit your information, if wrong.</marquee></span>
	<div id="left_side">
		<br><br><br>
		<form action="" method="post">
			<table>
				<tr>
					<td>
						<input type="submit" name="search_student" value="Search Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="edit_student" value="Edit Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_new_student" value="Add New Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="delete_student" value="Delete Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_courses" value="Show Courses">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_courses" value="Add Courses">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="delete_courses" value="Delete Courses">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_fees" value="Show Fees">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_score_card" value="Show Score Card">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="edit_score_card" value="Edit Score Card">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_score_card" value="Add Score Card">
					</td>
				</tr>
				<tr>
					<td>
						<!--<input type="submit" name="generate_pdf" value="Generate Status PDF">-->
						<a href="generate_pdf.php" >GENERATE STATUS PDF</a>
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div id="right_side"><br><br>
		<div id="demo">
		<!-- #Code for search student---Start-->
			<?php
				if(isset($_POST['search_student']))
				{
					?>
					<center>
					<form action="" method="post">
					&nbsp;&nbsp;<b>Enter College ID:</b>&nbsp;&nbsp; <input type="text" name="clg_id">
					<input type="submit" name="search_by_clg_id_for_search" value="Search">
					</form><br><br>
					<h4><b><u>Student's details</u></b></h4><br><br>
					</center>
					<?php
				}
				if(isset($_POST['search_by_clg_id_for_search']))
				{
					$query = "select * from student where clg_id = '$_POST[clg_id]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<table>
							<tr>
								<td>
									<b>College ID:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['clg_id']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['name']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>DOB:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['dob']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Phone Number:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['phone_no']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Email:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['email']?>" disabled>
								</td>
							</tr>
						</table>
						<?php
					}
				}
			?>
		<!-- #Code for edit student details---Start-->
		<?php
			if(isset($_POST['edit_student']))
			{
				?>
				<center>
				<form action="" method="post">
				&nbsp;&nbsp;<b>Enter College ID:</b>&nbsp;&nbsp; <input type="text" name="clg_id">
				<input type="submit" name="search_by_clg_id_for_edit" value="Search">
				</form><br><br>
				<h4><b><u>Student's details</u></b></h4><br><br>
				</center>
				<?php
			}
			if(isset($_POST['search_by_clg_id_for_edit']))
			{
				$query = "select * from student where clg_id = '$_POST[clg_id]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					?>
					<form action="admin_edit_student.php" method="post">
						<table>
						<tr>
							<td>
								<b>College ID:</b>
							</td> 
							<td>
								<input type="text" name="clg_id" value="<?php echo $row['clg_id']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Name:</b>
							</td> 
							<td>
								<input type="text" name="name" value="<?php echo $row['name']?>">
							</td>
						</tr>
						<tr>
								<td>
									<b>DOB:</b>
								</td> 
								<td>
									<input type="text" name="dob" value="<?php echo $row['dob']?>">
								</td>
							</tr>
							<tr>
								<td>
									<b>Phone Number:</b>
								</td> 
								<td>
									<input type="text" name="phone_no" value="<?php echo $row['phone_no']?>">
								</td>
							</tr>
						<tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="email" value="<?php echo $row['email']?>">
							</td>
						</tr>
						<br>
						<tr>
							<td></td>
							<td>
								<input type="submit" name="edit" value="Save">
							</td>
						</tr>
					</table>
					</form>
					<?php
				}
			}
		?>
		<!-- #Code for Delete student details---Start-->
		<?php
			if(isset($_POST['delete_student']))
			{
				?>
				<center>
				<form action="delete_student.php" method="post">
				&nbsp;&nbsp;<b>Enter College ID:</b>&nbsp;&nbsp; <input type="text" name="clg_id">
				<input type="submit" name="search_by_clg_id_for_delete" value="Delete">
				</form><br><br>
				</center>
				<?php
			}
			?>

			<?php 
				if(isset($_POST['add_new_student'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_student.php" method="post">
						<table>
						<tr>
							<td>
								<b>College ID:</b>
							</td> 
							<td>
								<input type="text" name="clg_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Name:</b>
							</td> 
							<td>
								<input type="text" name="name" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>DOB:</b>
							</td> 
							<td>
								<input type="text" name="dob" required>
							</td>
						</tr>
						
						<tr>
							<td>
								<b>Phone Number:</b>
							</td> 
							<td>
								<input type="text" name="phone_no" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="email" required>
							</td>
						</tr>
						
						<tr>
							<td></td>
							<td><br><input type="submit" name="add" value="Add Student"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
			<?php
				if(isset($_POST['show_courses']))
				{
					?>
					<center>
						<h5>Course Details</h5>
						<table>
							<tr>
								<td id="td"><b>Course ID</b></td>
								<td id="td"><b>Course Name</b></td>
								
							</tr>
						</table>
					</center>
					<?php
					$query = "select * from courses";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<center>
						<table style="border-collapse: collapse;border: 1px solid black;">
							<tr>
								<td id="td"><?php echo $row['course_id']?></td>
								<td id="td"><?php echo $row['coursename']?></td>
								
							</tr>
						</table>
						</center>
						<?php
					}
				}
			?>
			<?php 
				if(isset($_POST['add_courses'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_courses.php" method="post">
						<table>
						<tr>
							<td>
								<b>Course ID:</b>
							</td> 
							<td>
								<input type="text" name="course_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Course Name:</b>
							</td> 
							<td>
								<input type="text" name="coursename" required>
							</td>
						</tr>
	
						
						<tr>
							<td></td>
							<td><br><input type="submit" name="add" value="Add Course"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
			<?php
			if(isset($_POST['delete_courses']))
			{
				?>
				<center>
				<form action="delete_courses.php" method="post">
				&nbsp;&nbsp;<b>Enter Course ID:</b>&nbsp;&nbsp; <input type="text" name="course_id">
				<input type="submit" name="search_by_course_id_for_delete" value="Delete">
				</form><br><br>
				</center>
				<?php
			}
			?>
			<?php
				if(isset($_POST['show_fees']))
				{
					?>
					<center>
						<table>
							<tr>
								<td id="td"><b>College ID</b></td>
								<td id="td"><b>Semwise Fee</b></td>
								<td id="td"><b>Hostel Fee</b></td>
								<td id="td"><b>Bus Fee</b></td>
								
							</tr>
						</table>
					</center>
					<?php
					$query = "select * from fees";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<center>
						<table style="border-collapse: collapse;border: 1px solid black;">
							<tr>
								<td id="td"><?php echo $row['clg_id']?></td>
								<td id="td"><?php echo $row['semwise_fee']?></td>
								<td id="td"><?php echo $row['hostel_fee']?></td>
								<td id="td"><?php echo $row['bus_fee']?></td>
								
							</tr>
						</table>
						</center>
						<?php
					}
				}
			?>
			<?php
				if(isset($_POST['show_score_card']))
				{
					?>
					<center>
					<form action="" method="post">
					  	College ID: <input type="text" name="clg_id" required><br><br>
                      	Semester: <input type="text" name="semester" required><br><br>
					 	<input type="submit" name="search_by_semester_for_search" value="Search">
					</form><br><br>
					<h4><b><u>Score Card</u></b></h4><br><br>
					</center>
					<?php
				}
				if(isset($_POST['search_by_semester_for_search']))
				{
					$query = "select course_id,tot_internal from score_card where semester = '$_POST[semester]' and clg_id = '$_POST[clg_id]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<table>
							<tr>
								<td>
									<b>Course ID:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['course_id']?>" disabled>
								</td>
								
								<td>
									<b>Total Internal:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['tot_internal']?>" disabled>
								</td>
							</tr><br>
							
						</table>
						<?php
					}
				}
			?>
			<?php
				if(isset($_POST['edit_score_card']))
				{
					?>
					<center>
					<form action="" method="post">
						College ID: <input type="text" name="clg_id" required><br><br>
                      	Semester: <input type="text" name="semester" required><br><br>
						Course ID: <input type="text" name="course_id" required><br><br>
					 	<input type="submit" name="search_by_sem_for_edit" value="Search">
					</form><br><br>
					<h4><b><u>Score Card</u></b></h4><br><br>
					</center>
					<?php	
				}
				if(isset($_POST['search_by_sem_for_edit']))
				{									
					$query = "select clg_id , semester , course_id , tot_internal from score_card where clg_id = '$_POST[clg_id]' and semester = '$_POST[semester]' and course_id = '$_POST[course_id]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<form action="score_card_edit.php" method="post">
							<table>
							<tr>
								<td>
									<b>Total Internal:</b>
								</td> 
								<td>
									<input type="text" name="tot_internal" value="<?php echo $row['tot_internal']?>">
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<input type="submit" name="edit" value="Save">
								
								</td>
							</tr>	
							<input type="hidden" name="clg_id" value="<?php echo $row['clg_id']?>">	
								
							<input type="hidden" name="semester" value="<?php echo $row['semester']?>">
								
							<input type="hidden" name="course_id" value="<?php echo $row['course_id']?>">
																								
						</table>
						</form>
			        	<?php
					}
				}
			?>
			<?php 
				if(isset($_POST['add_score_card'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_score_card.php" method="post">
						<table>
						<tr>
							<td>
								<b>College ID:</b>
							</td> 
							<td>
								<input type="text" name="clg_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Semester:</b>
							</td> 
							<td>
								<input type="text" name="semester" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Course ID:</b>
							</td> 
							<td>
								<input type="text" name="course_id" required>
							</td>
						</tr>
						
						<tr>
							<td>
								<b>Total Internal:</b>
							</td> 
							<td>
								<input type="text" name="tot_internal" required>
							</td>
						</tr>
						
						
						<tr>
							<td></td>
							<td><br><input type="submit" name="add" value="Add Score Card"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
		</div>
	</div>
</body>
</html>