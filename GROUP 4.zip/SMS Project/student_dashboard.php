<!DOCTYPE html>
<html>
<head>
	<title>Student Dashboard</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
	  <style type="text/css">
		#header{
			height: 10%;
			width: 100%;
			top: 2%;
			background-color: black;
			position: fixed;
			color: white;
		}
		#left_side{
			height: 75%;
			width: 15%;
			top: 10%;
			position: fixed;
		}
		#right_side{
			height: 75%;
			width: 80%;
			background-color: whitesmoke;
			position: fixed;
			overflow-y:scroll;
			left: 17%;
			top: 18%;
			color: red;
			border: solid 1px black;
		}
		#top_span{
			top: 15%;
			width: 80%;
			left: 17%;
			position: fixed;
		}
	</style>
	<?php
		session_start();
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"sms");
	?>
</head>
<body>
	<div id="header"><br>
		<center>Student Management System &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;User ID: <?php echo $_SESSION['clg_id'];?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name:<?php echo $_SESSION['name'];?> 
		<a href="logout.php">Logout</a>
		</center>
	</div>
	<span id="top_span"><marquee>Note:- This portal is open till 31 March 2021...Please edit your information, if wrong.</marquee></span>
	<div id="left_side">
		<br><br><br>
		<form action="" method="post">
		
			<table>
				<tr>
					<td>
						<input type="submit" name="edit_detail" value="Edit Student Detail">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_detail" value="Show Student Detail">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_fees" value="Show Fees Details">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show_score_card" value="Show Score Card">
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div id="right_side"><br><br>
		<div id="demo">
			<?php
			if(isset($_POST['show_detail']))
			{
				$query = "select * from student where clg_id = '$_SESSION[clg_id]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
			?>
				<table>
					<tr>
						<td>
							<b>College ID:</b>
						</td> 
						<td>
							<input type="text" value="<?php echo $row['clg_id']?>" disabled>
						</td>
					</tr>
					<tr>
						<td>
							<b>Name:</b>
						</td> 
						<td>
							<input type="text" value="<?php echo $row['name']?>" disabled>
						</td>
					</tr>
					<tr>
						<td>
							<b>DOB:</b>
						</td> 
						<td>
							<input type="text" value="<?php echo $row['dob']?>" disabled>
						</td>
					</tr>
					<tr>
						<td>
							<b>Phone Number:</b>
						</td> 
						<td>
							<input type="text" value="<?php echo $row['phone_no']?>" disabled>
						</td>
					</tr>
					<tr>
						<td>
							<b>Email:</b>
						</td> 
						<td>
							<input type="text" value="<?php echo $row['email']?>" disabled>
						</td>
					</tr>
				</table>
				<?php
				}	
			}
			?> 
			

			<?php
			if(isset($_POST['edit_detail']))
			{
				$query = "select * from student where clg_id = '$_SESSION[clg_id]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					?>
					<form action="edit_student.php" method="post">
						<table>
						
						<tr>
							<td>
								<b>Name:</b>
							</td> 
							<td>
								<input type="text" name="name" value="<?php echo $row['name']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>DOB:</b>
							</td> 
							<td>
								<input type="text" name="dob" value="<?php echo $row['dob']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Phone Number:</b>
							</td> 
							<td>
								<input type="text" name="phone_no" value="<?php echo $row['phone_no']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="email" value="<?php echo $row['email']?>">
							</td>
						</tr>
						<br>
						<tr>
							<td></td>
							<td>
								<input type="submit" value="Save">
							</td>
						</tr>
						<input type="text" name="clg_id" value="<?php echo $row['clg_id']?>" style="display:none">
					</table>
					</form>
					<?php
				}
			}
			?>
			<?php
				if(isset($_POST['show_fees']))
				{
					$query = "select * from fees where clg_id='$_SESSION[clg_id]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{


						?>
						<center>
						<h3>Fees Details</h3>
						<tr>
							<td>
								<b>College ID:</b>
							</td> 
							<td>
								<input type="text" value="<?php echo $row['clg_id']?>" disabled>
							</td>
						</tr>
						<br>
						<br>
						<tr>
							<td>
								<b>Semwise Fee:</b>
							</td> 
							<td>
								<input type="text" value="<?php echo $row['semwise_fee']?>" disabled>
							</td>
						</tr>
						<br>
						<br>
						<tr>
							<td>
								<b>Hostel Fee:</b>
							</td> 
							<td>
								<input type="text" value="<?php echo $row['hostel_fee']?>" disabled>
							</td>
						</tr>
						<br>
						<br>
						<tr>
							<td>
								<b>Bus Fee:</b>
							</td> 
							<td>
								<input type="text" value="<?php echo $row['bus_fee']?>" disabled>
							</td>
						</tr>
						<br>
						<br>
						</center>
						
						
						<?php
					}
				}
			?>
			<?php
				if(isset($_POST['show_score_card']))
				{
					$query = "select * from score_card where clg_id='$_SESSION[clg_id]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<table>
							<tr>
								<td>
									<b>Semester</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['semester']?>" disabled>
								</td>
								<td>
									<b>Course ID:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['course_id']?>" disabled>
								</td>
								
								<td>
									<b>Total Internal:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['tot_internal']?>" disabled>
								</td>
							</tr><br>
							
						</table>
						<?php
					}
				}
			?>
		</div>
	</div>
</body>
</html>