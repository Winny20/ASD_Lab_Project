<!DOCTYPE html>
<html>
<head>
	<title>Student Login</title>
</head>
<body>
	<center><br><br>
		<h3>Student LogIn Page</h3><br>
		<form action="" method="post">
			User ID: <input type="text" name="clg_id" required><br><br>
			Password: <input type="password" name="dob" required><br><br>
			<input type="submit" name="submit" value="LogIn">
		</form><br>
		<?php
			session_start();
			if(isset($_POST['submit']))
			{
				$connection = mysqli_connect("localhost","root","");
				$db = mysqli_select_db($connection,"sms");
				$query = "select * from student where clg_id = '$_POST[clg_id]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					if($row['clg_id'] == $_POST['clg_id'])
					{
						if($row['dob'] == $_POST['dob'])
						{
							$_SESSION['name'] =  $row['name'];
							$_SESSION['clg_id'] =  $row['clg_id'];
							header("Location: student_dashboard.php");
						}
						else{
							?>
							<span>Wrong Password !!</span>
							<?php
						}
					}
					else
					{
						?>
						<span>Wrong UserName !!</span>
						<?php
					}
				}
			}
		?>
	</center>
</body>
</html>