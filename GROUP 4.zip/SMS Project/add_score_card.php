<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
    $query = "insert into score_card values('$_POST[clg_id]','$_POST[semester]','$_POST[course_id]',$_POST[tot_internal])";
    echo $query;
    $query_run = mysqli_query($connection,$query);
    
?>
<script type="text/javascript">
	alert("Score Card added successfully.");
	window.location.href = "admin_dashboard.php";
</script>
