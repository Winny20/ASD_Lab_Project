<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	
</head>
<body>
	<center><br><br>
		<h3>Admin LogIn Page</h3><br>
		<form action="" method="post">
			User_id: <input type="text" name="user_id" required><br><br>
			Password: <input type="password" name="password" required><br><br>
			<input type="submit" name="submit" value="LogIn">
		</form><br>
		
		<?php
			session_start();
			if(isset($_POST['submit'])){
				$connection = mysqli_connect("localhost","root","");
				$db = mysqli_select_db($connection,"sms");
				$query = "select * from admin where user_id = '$_POST[user_id]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) {
					if($row['user_id'] == $_POST['user_id']){
						if($row['password'] == $_POST['password']){
							$_SESSION['name'] =  $row['name'];
							$_SESSION['user_id'] =  $row['user_id'];
							header("Location: admin_dashboard.php");
						}
						else{
							?>
							<span>Wrong Password !!</span>
							<?php
						}
					}
				}
				
			}
		?>
	</center>
</body>
</html>